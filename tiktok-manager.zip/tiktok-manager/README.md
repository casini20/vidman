# TikTok Manager

Upload a video once — post it to all your TikTok accounts automatically.

Built with Next.js (frontend) + FastAPI + Playwright (backend). No official TikTok API needed.

---

## How it works

- You export your TikTok session cookies using the **Cookie-Editor** browser extension
- The dashboard stores those cookies and uses **Playwright** (a real browser) to log in and post on your behalf
- Upload a video, write a caption, select which accounts to post to — done

---

## Project structure

```
tiktok-manager/
├── frontend/    → Next.js app  (deploy to Vercel)
└── backend/     → FastAPI app  (deploy to Railway)
```

---

## Deployment

### 1. Backend → Railway

> Railway gives you $5/month free credit, plenty for this.

1. Go to [railway.app](https://railway.app) and sign up (free)
2. Click **New Project → Deploy from GitHub repo**
3. Select this repo and set the **root directory** to `backend`
4. Railway will auto-detect the `Dockerfile` and build it
5. Add these environment variables in Railway's **Variables** tab:
   - `FRONTEND_URL` → your Vercel URL (e.g. `https://your-app.vercel.app`)
   - `HEADLESS` → `true`
6. Copy the Railway public URL (e.g. `https://tiktok-manager-backend.railway.app`)

### 2. Frontend → Vercel

1. Go to [vercel.com](https://vercel.com) and sign up (free)
2. Click **Add New → Project → Import Git Repository**
3. Select this repo and set the **root directory** to `frontend`
4. Add this environment variable:
   - `NEXT_PUBLIC_API_URL` → your Railway URL from step 1 (no trailing slash)
5. Deploy — Vercel gives you a URL like `https://your-app.vercel.app`
6. Go back to Railway and set `FRONTEND_URL` to this Vercel URL

---

## Connecting accounts

1. Install [Cookie-Editor](https://chrome.google.com/webstore/detail/cookie-editor/hlkenndednhfkekhgcdicdfddnkalmdm) for Chrome or Firefox
2. Go to [tiktok.com](https://www.tiktok.com) and log in to the account you want to add
3. Click the Cookie-Editor icon → **Export** → **Export as JSON**
4. Open your dashboard → **Accounts** → **Connect account**
5. Paste the JSON and click Connect

Repeat for each account. The backend will verify the session, scrape your profile info, and save everything.

---

## Posting a video

1. Go to **Upload** in the sidebar
2. Drop in your video file (MP4 recommended)
3. Write your caption
4. Select which accounts to post to
5. Hit **Post** — the backend opens a browser per account and uploads automatically

You'll see a live result when it's done, showing which accounts succeeded or failed.

---

## Running locally

### Backend

```bash
cd backend
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
playwright install chromium
cp .env.example .env
uvicorn main:app --reload
```

### Frontend

```bash
cd frontend
npm install
cp .env.example .env.local
# Edit .env.local: NEXT_PUBLIC_API_URL=http://localhost:8000
npm run dev
```

---

## Notes

- **TikTok selectors can change.** If posting breaks after a TikTok update, check `backend/services/tiktok.py` and update the CSS selectors.
- **Cookies expire.** TikTok sessions last a few weeks. When posting fails, reconnect that account by re-exporting cookies.
- **Don't post to dozens of accounts at once.** Start with 2–3. Space out posts to avoid triggering TikTok's bot detection.
- This tool uses browser automation which is against TikTok's ToS. Use responsibly.
